class InvalidConfiguration(Exception):
    pass
