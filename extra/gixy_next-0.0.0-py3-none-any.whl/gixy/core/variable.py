import functools
import logging
import re

from gixy.core.context import get_context
from gixy.core.regexp import Regexp

LOG = logging.getLogger(__name__)
# See ngx_http_script_compile in http/ngx_http_script.c
EXTRACT_RE = re.compile(r"\$([1-9]|[a-z_][a-z0-9_]*|\{[a-z0-9_]+\})", re.IGNORECASE)
# See ngx_http_geo_module.c: parameters that configure the block instead of providing a value
GEO_PARAMETERS = frozenset(
    ("delete", "include", "proxy", "proxy_recursive", "ranges", "volatile")
)
_query_results = None


def memoize_query(method):
    @functools.wraps(method)
    def wrapper(*args):
        global _query_results
        if _query_results is None:
            _query_results = {}
            try:
                return wrapper(*args)
            finally:
                _query_results = None
        key = (method,) + args
        if key not in _query_results:
            _query_results[key] = method(*args)
        return _query_results[key]

    return wrapper


def compile_script(script, ctx=None):
    """
    Compile Nginx script to list of variables.
    Example:
        compile_script('http://$foo:$bar') ->
            [Variable('http://'), Variable($foo), Variable(':', Variable($bar).

    :param str script: Nginx scrip.
    :return Variable[]: list of variable.
    """
    depends = []
    context = get_context()
    for i, var in enumerate(EXTRACT_RE.split(str(script))):
        if i % 2:
            # Variable
            var_val = var.strip("{}\x20").lower()
            var = context.get_var(var_val, ctx=ctx)
            if var:
                depends.append(var)
            else:
                LOG.info(
                    "Can't find variable '{0}' in script '{1}' inside block '{2}'.".format(
                        var_val, script, str(context.block).replace("\n", " ")
                    )
                )
        elif var:
            # Literal
            depends.append(Variable(name=None, value=var, have_script=False, ctx=ctx))
    return depends


def compile_hash_entry(var):
    """
    Compile a single entry of a map/geo block into the variables it may resolve to.

    :param Variable var: entry taken from the value of a MapBlock/GeoBlock variable.
    :return Variable[]|None: entry dependencies, None if the entry provides no value.
    """
    # nginx_name is compared instead of importing MapDirective/MapBlock/GeoBlock, circular import..
    provider = var.provider if isinstance(var, Variable) else None
    if not provider or provider.nginx_name != "map":
        return None
    if provider.dest_val is None:
        return None

    block = provider.parent
    if not block or block.nginx_name not in ("map", "geo"):
        return None

    if block.nginx_name == "geo":
        if provider.src_val in GEO_PARAMETERS:
            return None
        # ngx_http_geo_module stores values verbatim, they are not nginx scripts
        return [Variable(name=None, value=provider.dest_val, have_script=False)]

    return compile_script(provider.dest_val, ctx=provider.src_val)


class Variable(object):
    def __init__(
        self,
        name,
        value=None,
        boundary=None,
        provider=None,
        have_script=True,
        ctx=None,
        alternatives=None,
    ):
        """
        Gixy Nginx variable class - parse and provide helpers to work with it.

        :param str|None name: variable name.
        :param str|Regexp value: variable value..
        :param Regexp boundary: variable boundary set.
        :param Directive provider: directive that provide variable (e.g. if, location, rewrite, etc.).
        :param bool have_script: may variable have nginx script or not (mostly used to indicate a string literal).
        :param str ctx: used for MapBlock/GeoBlock and MapDirective encapsulation
        :param tuple[Variable] alternatives: possible values after conditional assignments.
        """

        self.name = name
        self.value = value
        self.regexp = None
        self.depends = None
        self.boundary = boundary
        self.provider = provider
        self.final_value = value
        self.ctx = ctx
        self.alternatives = alternatives
        if isinstance(value, Regexp):
            self.regexp = value
        elif have_script and not alternatives:
            self.depends = compile_script(
                value, ctx
            )  # XXX: Do we want to append new_depends below?
            for iteration in range(
                10
            ):  # 10 is arbitrary, just avoid infinite loop (is it possible?)
                new_depends = compile_script(self.final_value, ctx)
                if len(new_depends) == 0:
                    break
                if any(isinstance(dep.value, list) or dep.alternatives for dep in new_depends):
                    # Hash values and conditional alternatives cannot be
                    # flattened into a single string.
                    self.depends = new_depends
                    self.final_value = self.value
                    break
                if len(new_depends) == 1 and self.final_value == new_depends[0].value:
                    break
                self.depends = new_depends
                all_vars = [str(i.value) for i in new_depends]
                self.final_value = "".join(all_vars)

    @memoize_query
    def can_contain(self, char):
        """
        Checks if variable can contain the specified char.

        :param str char: character to test.
        :return: True if variable can contain the specified char, False otherwise.
        """

        # First of all check boundary set
        if self.boundary and not self.boundary.can_contain(char):
            return False

        # Then regexp
        if self.regexp:
            return self.regexp.can_contain(char, skip_literal=True)

        if self.alternatives:
            return any(var.can_contain(char) for var in self.alternatives)

        # Then dependencies
        if self.depends:
            return any(dep.can_contain(char) for dep in self.depends)

        # If the value is a list (hash block), check all dest_val values
        if isinstance(self.value, list):
            for var in self.value:
                if (
                    not isinstance(var, Variable)
                    or not var.provider
                    or var.provider.nginx_name != "map"
                ):  # import MapDirective would be better but circular import..
                    continue  # break?
                if (
                    var.provider.parent.nginx_name != "map"
                ):  # import MapBlock would be better but circular import..
                    continue  # break?

                compiled_val = compile_script(
                    var.provider.dest_val, ctx=var.provider.src_val
                )
                # Doesn't work for 'map $document_uri $v { ~*^[^\r\n]+$ $document_uri; }'
                # but nothing we can do about that.
                for dep in compiled_val:
                    if dep.can_contain(char):
                        return True

        # Otherwise user can't control value of this variable
        return False

    @memoize_query
    def can_startswith(self, char):
        """
        Checks if variable can starts with the specified char.

        :param str char: character to test.
        :return: True if variable can starts with the specified char, False otherwise.
        """

        # First of all check boundary set
        if self.boundary and not self.boundary.can_startswith(char):
            return False

        # Then regexp
        if self.regexp:
            return self.regexp.can_startswith(char)

        if self.alternatives:
            return any(var.can_startswith(char) for var in self.alternatives)

        # Then dependencies
        if self.depends:
            return self.depends[0].can_startswith(char)

        # If the value is a list (hash block), check all values
        if isinstance(self.value, list):
            for var in self.value:
                if (
                    not isinstance(var, Variable)
                    or not var.provider
                    or var.provider.nginx_name != "map"
                ):
                    continue
                if var.provider.parent.nginx_name != "map":
                    continue

                compiled_val = compile_script(
                    var.provider.dest_val, ctx=var.provider.src_val
                )
                if compiled_val:
                    if compiled_val[0].can_startswith(char):
                        return True

        # Otherwise user can't control value of this variable
        return False

    @memoize_query
    def must_contain(self, char):
        """
        Checks if variable MUST contain the specified char.

        :param str char: character to test.
        :return: True if variable must contain the specified char, False otherwise.
        """

        # First of all check boundary set
        if self.boundary and self.boundary.must_contain(char):
            return True

        # Then regexp
        if self.regexp:
            return self.regexp.must_contain(char)

        if self.alternatives:
            return all(var.must_contain(char) for var in self.alternatives)

        # Then dependencies
        if self.depends:
            return any(dep.must_contain(char) for dep in self.depends)

        # If the value is a list (hash block), check all values
        if isinstance(self.value, list):
            # Ensure that every map value must contain the char
            has_default = False
            for var in self.value:
                compiled_val = compile_hash_entry(var)
                if compiled_val is None:
                    continue

                found_must_contain = False
                for dep in compiled_val:
                    if dep.must_contain(char):
                        found_must_contain = True
                        break
                if not found_must_contain:  # A map value doesn't need to contain the char, therefore return False
                    return False
                if var.provider.src_val == "default":
                    has_default = True

            return has_default

        # Otherwise checks literal
        return self.value and char in self.value

    @memoize_query
    def must_startswith(self, char):
        """
        Checks if variable MUST starts with the specified char.

        :param str char: character to test.
        :return: True if variable must starts with the specified char.
        """

        # First of all check boundary set
        if self.boundary and self.boundary.must_startswith(char):
            return True

        # Then regexp
        if self.regexp:
            return self.regexp.must_startswith(char)

        if self.alternatives:
            return all(var.must_startswith(char) for var in self.alternatives)

        # Then dependencies
        if self.depends:
            return self.depends[0].must_startswith(char)

        # If the value is a list (hash block), check all values
        if isinstance(self.value, list):
            has_default = False
            for var in self.value:
                compiled_val = compile_hash_entry(var)
                if compiled_val is None:
                    continue

                if not compiled_val or not compiled_val[0].must_startswith(char):
                    return False
                if var.provider.src_val == "default":
                    has_default = True

            return has_default

        # Otherwise checks literal
        return self.value and self.value[0] == char

    @property
    def options(self):
        """
        Returns the values variable may take after conditional assignments.

        :return Variable[]: variables without alternatives, except stand-ins for variables not assigned yet.
        """
        result, seen = [], set()

        def collect(var):
            if var in seen:
                return
            seen.add(var)
            copied = var.depends[0] if var.depends and len(var.depends) == 1 else None
            alternatives = var.alternatives or (copied.alternatives if copied else None)
            if not alternatives and not (var.provider is None and var.value == var.name):
                result.append(var)
            for option in alternatives or ():
                collect(option)

        collect(self)
        return result

    @property
    def providers(self):
        """
        Returns list of variable provides.

        :return Directive[]: providers.
        """
        result, seen = [], set()

        def collect(var):
            if var in seen:
                return
            seen.add(var)
            if var.provider:
                result.append(var.provider)
            for dep in var.depends or var.alternatives or ():
                collect(dep)

        collect(self)
        return result
